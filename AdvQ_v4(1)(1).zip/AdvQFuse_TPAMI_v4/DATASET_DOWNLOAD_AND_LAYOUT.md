# AdvQFuse Dataset Download, Layout, and Verification Guide

Verified on 25 July 2026. Prefer the original dataset publisher when an official source exists. A third-party mirror can be used for engineering convenience, but record the mirror URL, commit/revision, file counts, and checksums in the experiment log.

## 1. Scientific role of each remote-sensing dataset

These datasets remain relevant, but they are the **specialized-domain and multimodal stress-test portion** of the TPAMI study, not the entire paper.

| Dataset | Keep? | Role in the redesigned study | Main caution |
|---|---:|---|---|
| EarthVQA | Yes | Remote-sensing relational reasoning, counting, and comprehensive QA | Official data access is through the project download page; placeholder `wget` commands are invalid. |
| FloodNet VQA | Yes | Safety-critical UAV disaster reasoning and subgroup risk analysis | The Hugging Face copy is a third-party rehost; preserve its exact revision. |
| RSVQA-HR | Yes | High-resolution specialized-domain generalization | Keep `USGS_*` files separate from low-resolution `LR_*` files. |
| RSVQA-LR | Optional | Resolution-shift and leave-one-dataset-out supplementary experiment | Do not mix LR annotations with HR images or claim it as RSVQA-HR. |
| UAV-OBB-QA | Yes, as a derived benchmark | Author-specific counting, existence, class dominance, and orientation reasoning | Regenerate with the supplied parser; the earlier script creates biased and collision-prone QA. |
| SEN12MS | Yes, but not as an official QA benchmark | Optical-SAR cross-sensor conflict, modality dropout, and land-cover reasoning | `SEN12MS-QA` is a derived task. Optical and SAR files alone are insufficient without land-cover labels or a reproducible answer-generation protocol. |

For a TPAMI submission, also include broad, non-remote-sensing benchmarks such as VQAv2, GQA, TextVQA, POPE, ScienceQA-image, and recognition-shift datasets. The central conclusion must survive removal of all remote-sensing data.

## 2. Recommended project-relative directory tree

Large datasets do **not** have to be physically copied into the repository. The cleanest approach is to leave them under `/content` and let `configs/datasets.local.yaml` point to the real locations. When a self-contained tree is preferred, use:

```text
AdvQFuse_TPAMI_v4/
├── configs/
│   ├── datasets.local.example.yaml
│   └── datasets.local.yaml              # machine-specific absolute roots; do not commit
├── data/
│   ├── raw/
│   │   ├── earthvqa/
│   │   │   ├── Train/images_png/
│   │   │   ├── Train/masks_png/
│   │   │   ├── Val/images_png/
│   │   │   ├── Val/masks_png/
│   │   │   ├── Test/images_png/
│   │   │   ├── Test/masks_png/           # when included in the release
│   │   │   ├── Train_QA.json
│   │   │   ├── Val_QA.json
│   │   │   └── Test_QA.json
│   │   ├── floodnet/
│   │   │   ├── train_image/{img,ann}/
│   │   │   ├── valid_image/{img,ann}/
│   │   │   ├── test_image/{img,ann}/
│   │   │   ├── README.md
│   │   │   └── meta.json
│   │   ├── rsvqa_hr/
│   │   │   ├── images/
│   │   │   ├── annotations/
│   │   │   │   ├── USGS_split_train_questions.json
│   │   │   │   ├── USGS_split_train_answers.json
│   │   │   │   ├── USGS_split_val_questions.json
│   │   │   │   ├── USGS_split_val_answers.json
│   │   │   │   ├── USGS_split_test*_questions.json
│   │   │   │   └── USGS_split_test*_answers.json
│   │   │   └── archives/                 # optional retained source archives
│   │   ├── rsvqa_lr/
│   │   │   ├── images/
│   │   │   └── annotations/LR_split_*.json
│   │   ├── uav_obb/
│   │   │   ├── train/{images,labels}/
│   │   │   ├── valid/{images,labels}/
│   │   │   ├── test/{images,labels}/
│   │   │   ├── data.yaml
│   │   │   └── test_videos_mp4/          # or the video files supplied by the version used
│   │   └── sen12ms/
│   │       ├── ROIs1158_spring_s1/
│   │       ├── ROIs1158_spring_s2/
│   │       ├── ROIs1158_spring_lc/
│   │       ├── ROIs1868_summer_s1/
│   │       ├── ROIs1868_summer_s2/
│   │       ├── ROIs1868_summer_lc/
│   │       ├── ROIs1970_fall_{s1,s2,lc}/
│   │       └── ROIs2017_winter_{s1,s2,lc}/
│   ├── derived/
│   │   ├── manifests/
│   │   │   ├── earthvqa.jsonl
│   │   │   ├── floodnet.jsonl
│   │   │   ├── rsvqa_hr.jsonl
│   │   │   ├── rsvqa_lr.jsonl
│   │   │   └── uav_obb_qa.jsonl
│   │   ├── uav_obb_qa/
│   │   └── sen12ms_qa/                   # reproducibly generated questions/answers
│   ├── attacks/
│   └── cache/
├── results/
│   ├── dataset_validation.json
│   ├── manifests/
│   ├── predictions/
│   ├── attacks/
│   ├── metrics/
│   └── qualitative_cases/
└── figures/
```

## 3. Diagnosis of the directory shown in the screenshots

### FloodNet

The screenshot layout `/content/FloodNet_VQA/{train_image,valid_image,test_image}/{img,ann}` is compatible with the supplied adapter. It can remain exactly where it is.

### UAV-OBB

The data are correctly extracted but deeply nested. The effective dataset root is the **deepest** folder containing all of the following:

```text
data.yaml
train/images  train/labels
valid/images  valid/labels
test/images   test/labels
```

The scanner locates this root automatically, so the archive does not need to be moved. The old `uav_obb_questions.json` should be treated as obsolete and regenerated with the new parser.

### RSVQA

The screenshot shows two problems:

1. `LR_split_*` files are loose under `/content`; these belong to `rsvqa_lr/annotations`, not `rsvqa_hr`.
2. `Images.tar` has not clearly been extracted into the HR image directory. `USGS_split_*` files belong to RSVQA-HR.

Use the supplied organizer in **link mode** to avoid duplicating many gigabytes.

### SEN12MS

The current `/content/sen12ms_qa/{optical,sar}` structure is useful for visual pilot panels but is not yet an evaluable benchmark. Add either:

- the official matched `_lc` land-cover rasters; or
- an immutable `labels.csv` generated from the official probability/IGBP labels, with the generation script and version recorded.

### EarthVQA

EarthVQA is not visible in the screenshots. It is therefore missing from the current workspace unless stored elsewhere.

## 4. Verified download routes

### EarthVQA

The code repository and data are separate. Clone the official code repository, then use the official EarthVQA project page to request/download the data. Do not use `git clone https://github.com` or `wget https://whu.edu.cn`; neither points to the dataset.

```bash
git clone https://github.com/Junjue-Wang/EarthVQA.git EarthVQA_code
mkdir -p /content/EarthVQA
# Download the archive from the official project-page Google Drive link,
# upload/mount it in Colab, then extract it into /content/EarthVQA.
```

After extraction, verify that `Train_QA.json`, `Val_QA.json`, `Test_QA.json`, and the `Train/Val/Test` image folders exist.

### FloodNet VQA

Preferred scientific source: the original FloodNet publisher/repository. The following Hugging Face command is a convenient rehost and matches the structure shown in the screenshots:

```bash
python -m pip install -U "huggingface_hub[cli]"
hf download takara-ai/FloodNet_2021-Track_2_Dataset_HF \
  --repo-type dataset \
  --local-dir /content/FloodNet_VQA
```

Record the resolved Hugging Face commit in the experiment metadata. Do not describe the rehost as the original publisher.

### RSVQA-HR and RSVQA-LR

Official records:

- high resolution: Zenodo record `6344367`;
- low resolution: Zenodo record `6344334`.

```bash
python -m pip install -U zenodo-get
mkdir -p /content/downloads/rsvqa_hr /content/downloads/rsvqa_lr
zenodo_get 6344367 -o /content/downloads/rsvqa_hr
zenodo_get 6344334 -o /content/downloads/rsvqa_lr
```

Do not use broad wildcard `unzip "*.zip"` pipelines. Inspect archive names and extract HR and LR separately. The package organizer safely separates `USGS_*` and `LR_*` files.

### UAV-OBB

Prefer the official Mendeley Data release over a Kaggle mirror. Dataset revisions have changed; pin the DOI/version used by the experiment and preserve checksums. The package accepts the official YOLO-style structure and the nested Kaggle mirror shown in the screenshots.

For the Kaggle mirror already used:

```python
import opendatasets as od
od.download("https://www.kaggle.com/datasets/jocelyndumlao/uav-obb-urban-vehicle-detection-dataset")
```

This is acceptable as an engineering mirror, but the paper's data citation and version should refer to the official Mendeley release actually audited.

### SEN12MS

Use the official SEN12MS source/toolbox rather than the unverified `NoahZ/SEN12MS-Subset-Sample` command. A documented official download pattern is:

```bash
mkdir -p /content/sen12ms
cd /content/sen12ms
for season in 1158_spring 1868_summer 1970_fall 2017_winter; do
  for source in lc s1 s2; do
    wget "ftp://m1474000:m1474000@dataserv.ub.tum.de/ROIs${season}_${source}.tar.gz"
    tar -xzf "ROIs${season}_${source}.tar.gz"
  done
done
```

The full dataset is large. For a pilot, download a documented subset containing **all three matched modalities** (`s1`, `s2`, and `lc`) and preserve the official patch identifiers.

## 5. Why the earlier UAV-OBB QA generator should be replaced

The earlier script:

- scans unrelated `.txt` files;
- assumes every image is `.jpg`;
- stores only the basename, so equal filenames in different splits can collide;
- creates only positive existence questions, producing label imbalance;
- ignores `data.yaml` class names;
- does not reliably distinguish YOLO corner OBBs, center-angle OBBs, and DOTA-style annotations;
- omits the source split and label path needed for auditability.

The replacement in `src/qfuse/data/uav_obb_qa.py` supports the official YOLOv8-OBB corner format, a center-angle variant, and DOTA-style corners. It loads class names from `data.yaml`, preserves split-qualified IDs, generates negative existence questions, and adds class-dominance and circular-orientation questions.

## 6. Dataset integrity commands

From the repository root:

```bash
python scripts/scan_existing_datasets.py \
  --search-root /content \
  --output configs/datasets.local.yaml

python scripts/validate_datasets.py \
  --config configs/datasets.local.yaml \
  --report results/dataset_validation.json
```

Use strict mode only after every intended dataset has been downloaded:

```bash
python scripts/validate_datasets.py --config configs/datasets.local.yaml --strict
```

The validator checks required folders, image and annotation counts, unextracted RSVQA archives, nested UAV-OBB roots, and missing SEN12MS ground-truth labels.
