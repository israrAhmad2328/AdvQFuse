# AdvQFuse TPAMI v4 Research Package

**Quantization as a Reliability Probe: Precision-Path Risk Control for Vision-Language Models under Adversarial and Distribution Shift**

## Scientific position

This repository is a TPAMI-oriented redesign of the earlier remote-sensing-specific AdvQFuse-RS concept. Remote sensing remains a demanding transfer and multimodal-fusion domain, but it is not the title, exclusive scope, or central claim.

The broad question is:

> Can a model's prediction trajectory across controlled precision interventions reveal sample-specific failure risk, and can that signal support compute-aware, risk-controlled multimodal inference across unseen model families, tasks, datasets, precisions, and shifts?

Quantization is treated as a controlled parameter intervention. The resulting **precision path** is represented through predictive drift, rank changes, path curvature, semantic answer changes, hidden-state alignment, and cross-modal counterfactual evidence.

## Why this version is broader

The study design requires:

- at least four independent VLM families;
- BF16/FP16, INT8, INT4, and lower-precision path points where supported;
- at least three task families and eight datasets;
- clean, corruption, adversarial-image, adversarial-text, and image-text conflict evaluation;
- leave-one-model-family-out, leave-one-dataset-out, leave-one-attack-out, and unseen-precision tests;
- action-conditioned risk prediction for accept, reobserve, escalate, ensemble, and abstain;
- finite-sample group-wise selective-risk calibration;
- matched-compute accounting for every precision point, prompt, view, and intervention;
- results that remain positive when Bonsai and all remote-sensing datasets are removed.

## Dataset support added in v4

The package now includes audited layout detection and normalized manifest adapters for:

- EarthVQA;
- FloodNet VQA, including DatasetNinja/Hugging Face annotations with separate question and answer tags;
- RSVQA-HR and RSVQA-LR;
- nested official or mirrored UAV-OBB YOLOv8-OBB releases;
- SEN12MS structure validation with mandatory optical, SAR, and ground-truth land-cover evidence.

The UAV-OBB-QA generator now supports normalized corner OBBs, center-angle OBBs, and DOTA-style corners. It loads class names from `data.yaml`, preserves split-qualified identities, generates both positive and negative existence questions, and adds dominant-class and orientation questions.

Read:

- `DATASET_DOWNLOAD_AND_LAYOUT.md` for verified source routes and the canonical tree;
- `RUN_FROM_YOUR_CURRENT_COLAB.md` for commands matching the uploaded screenshots;
- `configs/datasets.colab.screenshot.example.yaml` for the visible `/content` paths.

## Core method

1. Evaluate aligned model checkpoints across a controlled precision ladder.
2. Compute precision-path geometry and cross-modal counterfactual features.
3. Encode the path with a lightweight set encoder or calibrated tabular baseline.
4. Estimate error and action-conditioned residual risk.
5. Select accept, reobserve, escalate, ensemble, or abstain under a calibrated risk bound.
6. Test transfer to held-out model families, datasets, attacks, and precision edges.

## Results and qualitative visualization suite

The complete package retains all earlier outputs and adds twelve new multi-panel layouts:

- Figures 1-24: quantitative robustness, calibration, uncertainty, policy, efficiency, and statistical analyses;
- Figures 25-36: qualitative attacks, recovery, uncertainty maps, optical-SAR fusion, failure cases, and answer audits;
- Figures 37-43: TPAMI-wide precision-path geometry, held-out generalization, matched-compute risk control, statistical evidence, and architecture;
- Figures 44-55: expanded per-sample audits, multi-attack recovery, cross-domain qualitative cases, subgroup calibration, compute routing, patch localization, optical-SAR conflict, prompt-by-precision lattices, group risk, model-family lattices, modality ablations, and residual-failure analysis.

All 55 current figures are explicitly watermarked synthetic layout demonstrations. They validate code and manuscript planning only; they are not scientific results.

## Quick start: current Colab workspace

```bash
python -m pip install -e ".[dev,plots]"
python scripts/scan_existing_datasets.py --search-root /content --output configs/datasets.local.yaml
python scripts/validate_datasets.py --config configs/datasets.local.yaml --report results/dataset_validation.json
python scripts/build_all_manifests.py --config configs/datasets.local.yaml --output-dir data/derived/manifests --include-rsvqa-lr
pytest -q
```

Generate the expanded visual suite:

```bash
python scripts/generate_v4_extended_suite.py
python scripts/build_full_figure_gallery.py
```

## Main outputs

- `figures/AdvQFuse_TPAMI_v4_55_Figure_Gallery.pdf`
- `figures/AdvQFuse_TPAMI_v4_55_Figure_Contact_Sheet.png`
- `paper/MANUSCRIPT_BLUEPRINT_TPAMI.md`
- `paper/RESULTS_VISUALIZATION_PLAN.md`
- `DATASET_DOWNLOAD_AND_LAYOUT.md`
- `RUN_FROM_YOUR_CURRENT_COLAB.md`
- `VALIDATION_REPORT.txt`

## Validation status

The package passes **29 automated tests** covering data layouts and adapters, UAV-OBB formats, uncertainty and fusion, risk control, precision paths, attacks, corruptions, the pipeline, and qualitative visualization utilities. The 55-figure gallery contains 56 PDF pages including the cover and was rendered for visual inspection.

Passing tests does not verify files on another Colab instance. Run the included dataset validator locally to audit the actual downloaded bytes and folder layout.

## Publication status

No publication or TPAMI acceptance can be guaranteed. The package is a complete research design and implementation framework, not a substitute for real multi-model experiments. A submission is justified only after held-out-family gains, group-wise risk validity, matched-compute benefit, adaptive-attack robustness, and real qualitative cases are all supported by locked test results.
