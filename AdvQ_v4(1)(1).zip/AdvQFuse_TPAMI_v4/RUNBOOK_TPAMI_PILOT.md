# TPAMI Pilot Runbook for RTX 4060 Ti 16 GB

## Purpose

Do not begin with the full 27B Bonsai study. First test the central scientific hypothesis on one controllable model family and a small but diverse sample. The pilot decides whether a TPAMI-scale investment is justified.

## Hardware-aware scope

A 16 GB RTX 4060 Ti is suitable for 3B-class VLM inference and carefully configured 7B quantized inference. It is not a practical platform for repeatedly loading several 27B path points with large batches. Treat Bonsai as a later server/offload case study.

## Stage 0 - Environment

```powershell
cd AdvQFuse_TPAMI_v4
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev,plots,attacks]"
pytest -q
```

Expected repository validation: all tests pass. Synthetic figures validate layout only.

## Stage 1 - Controlled-path feasibility

Use one open 3B checkpoint and construct BF16, INT8, and INT4 instances from the same base weights. Add INT3/INT2 only after the first three are stable.

Pilot sample:

- 500 VQAv2 examples;
- 500 GQA examples;
- 300 TextVQA examples;
- 300 POPE examples;
- 200 ImageNet-C prompt-classification examples.

For every example store:

- exact checkpoint and quantizer metadata;
- logits or normalized option probabilities;
- generated answer and parsed answer;
- final hidden summary when available;
- latency, peak VRAM, and estimated energy;
- clean/corrupted/attack label;
- correctness.

Do not generate only free-form confidence. A common answer space or reproducible answer-scoring method is required for path geometry.

## Stage 2 - Baseline signal test

Compare failure prediction using:

1. max probability;
2. entropy;
3. top-two margin;
4. view-augmentation consistency;
5. prompt-paraphrase consistency;
6. precision-path tabular features;
7. path plus counterfactual features.

Use sample-level train/calibration/test splits with no transformed copy of a test image in training.

### Pilot go/no-go threshold

Continue only when path features provide both:

- at least 0.03 absolute error-AUROC gain over the strongest confidence/consistency baseline on two task families; and
- a paired-bootstrap 95% confidence interval whose lower endpoint is above zero.

This is a practical project threshold, not a publication guarantee.

## Stage 3 - Second-family transfer

Repeat inference on a second independent architecture without retraining the path feature definition. Train the reliability model on family A and test on family B, then reverse.

Continue only if held-out-family gain remains positive and the result is not driven by one dataset.

## Stage 4 - Risk-control pilot

Create disjoint training, calibration, and test sets. Calibrate thresholds at alpha = 0.02, 0.05, and 0.10. Report:

- empirical selective risk;
- one-sided upper confidence bound;
- coverage;
- violation rate over five seeds;
- worst supported dataset/model/shift group.

Count the cost of every path point, paraphrase, view, and escalation. A controller that ignores probe cost is not a valid efficiency result.

## Stage 5 - Adversarial pilot

Use differentiable open checkpoints for white-box attacks. Include:

- image perturbation;
- adversarial patch;
- transfer attack;
- prompt-level attack;
- image-text contradiction.

Attack the complete decision pipeline where feasible, including the reliability score. Evaluating attacks only against the base answer model overstates defense robustness.

## Stage 6 - Full TPAMI matrix

Only after the pilot passes:

- expand to at least four independent model families;
- run eight or more datasets across three or more task families;
- execute leave-one-model, leave-one-dataset, and leave-one-attack tests;
- add remote sensing as a held-out specialized domain;
- add binary/ternary Bonsai without training the controller on sub-2-bit data.

## Memory controls

- Run one precision point at a time and write outputs to disk.
- Use batch size 1-2 for 7B VLMs.
- Disable gradients for clean/corruption inference.
- Generate adversarial examples on smaller differentiable models and evaluate transfer separately.
- Record CUDA peak allocated and reserved memory for every run.
- Use fixed sample IDs so every precision and baseline is paired.

## Final submission firewall

A TPAMI submission should not be prepared until:

- four independent families are complete;
- official or reproducible benchmark protocols are followed;
- held-out-family gains are statistically supported;
- risk targets are met group-wise;
- matched-compute benefit is demonstrated;
- Bonsai and remote sensing can be removed without destroying the main conclusion;
- qualitative figures come from real model outputs;
- all synthetic files are excluded from the manuscript evidence directory.
