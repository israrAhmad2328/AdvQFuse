# Windows 10 / RTX 4060 Ti 16 GB Runbook

## Recommended development sequence

### Phase 0: verify the original Bonsai demo

1. Use the repository's PowerShell setup.
2. Start with a 4B or 8B model to validate the API, vision input, and JSON output path.
3. Run the 27B 1-bit model next. Record load memory, image-prefill latency, decode speed, and maximum stable context.
4. Run the ternary 27B model separately. Do not try to keep binary and ternary 27B models resident simultaneously on a 16 GB card.

### Phase 1: collect paired-precision calibration data

For each calibration sample:

- run binary inference;
- unload or stop the binary server;
- run ternary inference;
- store class probabilities or constrained JSON confidence, latency, prompt-token count, decode-token count, and correctness;
- compute sensor quality features and corruption metadata.

Paired results can be cached, so training the external uncertainty estimator does not require both models to run simultaneously.

### Phase 2: train the lightweight QFuse modules

Use `scripts/fit_qfuse_controller.py` after paired records have been assigned to non-overlapping `train`, `cal`, and `test` splits. The code first trains a precision-sensitivity model to predict binary-versus-ternary disagreement from binary-pass observables, then trains a binary-failure predictor, and finally calibrates the acceptance threshold on the separate calibration split. This avoids test-time leakage from the ternary model.

The fusion and uncertainty modules are small CPU/GPU models. The supplied code begins with a ridge/logistic precision teacher and dependency-free logistic failure predictor; replace them with a 2-layer MLP only after the simple models are fully benchmarked.

Suggested MLP:

- input: 7-20 reliability features;
- hidden: 64, GELU, dropout 0.1;
- hidden: 32, GELU;
- output: one failure logit;
- loss: weighted BCE plus Brier calibration term;
- optimizer: AdamW, learning rate 3e-4, weight decay 1e-3;
- early stopping: validation AUROC and Brier score.

### Phase 3: deployment policy

At deployment, only the binary model runs first. `scripts/run_qfuse_decision.py` predicts quantization sensitivity and binary failure from binary-side features, then selects acceptance, re-perception, ternary escalation, or abstention. The ternary model is loaded only for escalated batches or evaluated offline to simulate the cascade. For a real interactive system, model swapping latency must be reported separately.

## Memory strategy

- Keep the multimodal projector on CPU when VRAM is tight.
- Start with 2K-8K context; long context is unnecessary for image classification experiments.
- Disable speculative decoding during quality benchmarking.
- Use temperature 0 for deterministic classification and repeat stochastic reasoning experiments separately.
- Avoid simultaneous 27B binary and ternary residency on 16 GB VRAM.

## Telemetry to log

- GPU model, driver, CUDA version, runtime commit, GGUF SHA256;
- resident VRAM, peak VRAM, system RAM;
- prompt processing tokens/s and generation tokens/s;
- first-token latency and end-to-end latency;
- wall energy when available; otherwise power sampled by `nvidia-smi` and integrated over time;
- image dimensions and vision-token cap;
- context length, KV precision, temperature, seed, reasoning budget.

## Practical first experiment

Use a 1,000-sample balanced subset with two modalities and three corruption severities. Split 50%/25%/25% for fitting the failure estimator, calibrating the risk threshold, and final testing. This is large enough to debug the pipeline but not large enough for a journal claim.
