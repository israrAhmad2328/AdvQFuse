# Legacy AdvQFuse-RS Materials

This package retains the previous 36 remote-sensing-oriented figure layouts and supporting scripts because they are useful for later specialized-domain experiments. They are **not** the TPAMI manuscript design.

For the TPAMI candidate, use these files first:

- `README.md`
- `paper/TPAMI_REDESIGN.md`
- `paper/MANUSCRIPT_BLUEPRINT_TPAMI.md`
- `paper/ABSTRACT_INTRO_CONTRIBUTIONS.md`
- `paper/EDITORIAL_FIREWALL.md`
- `paper/EIC_COVER_POSITIONING.md`
- `paper/EXPERIMENT_MATRIX.csv`
- `configs/tpami.yaml`
- `RUNBOOK_TPAMI_PILOT.md`
- `src/qfuse/precision_path.py`
- `src/qfuse/risk_controller.py`
- `figures/tpami_demo/`

Do not submit the earlier `QFuse_manuscript.pdf` or treat its synthetic results as evidence.
