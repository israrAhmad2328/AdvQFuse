# Run AdvQFuse from the Current Colab Directory

This runbook is written for the exact `/content` structure visible in the supplied screenshots. It avoids copying large datasets.

## A. Install and enter the repository

Upload `AdvQFuse_TPAMI_v4_complete_package.zip` to Colab, then run:

```python
!unzip -q /content/AdvQFuse_TPAMI_v4_complete_package.zip -d /content
%cd /content/AdvQFuse_TPAMI_v4
!python -m pip install -U pip
!python -m pip install -e ".[dev,plots]"
```

Install the attack dependencies only when attacks are being generated:

```python
!python -m pip install -e ".[attacks]"
```

## B. Preserve the existing datasets and scan their locations

```python
%cd /content/AdvQFuse_TPAMI_v4
!python scripts/scan_existing_datasets.py \
    --search-root /content \
    --output configs/datasets.local.yaml
!cat configs/datasets.local.yaml
```

The scanner should identify:

```text
floodnet  -> /content/FloodNet_VQA
uav_obb   -> deepest nested UAV-OBB folder containing data.yaml
sen12ms   -> /content/sen12ms_qa
rsvqa_hr  -> /content/rsvqa_hr
rsvqa_lr  -> /content, until loose LR files are organized
```

## C. Organize the loose RSVQA files without duplication

The screenshot has `Images.tar`, `LR_split_*`, `USGS_split_*`, and auxiliary JSON files under `/content`. Create symbolic links and extract the HR image archive:

```python
%cd /content/AdvQFuse_TPAMI_v4
!python scripts/organize_rsvqa_loose_files.py \
    --source-root /content \
    --data-root /content/AdvQFuse_TPAMI_v4/data/raw \
    --mode link \
    --extract-images
```

Then rescan from `/content`. The scanner scores the candidate RSVQA locations, preserves external FloodNet and UAV-OBB roots, and selects the deepest valid UAV-OBB directory automatically:

```python
!python scripts/scan_existing_datasets.py \
    --search-root /content \
    --output configs/datasets.local.yaml
!cat configs/datasets.local.yaml
```

The resulting configuration should resemble the following template:

```yaml
datasets:
  earthvqa:
    root: /content/EarthVQA
  floodnet:
    root: /content/FloodNet_VQA
  rsvqa_hr:
    root: /content/AdvQFuse_TPAMI_v4/data/raw/rsvqa_hr
  rsvqa_lr:
    root: /content/AdvQFuse_TPAMI_v4/data/raw/rsvqa_lr
  uav_obb:
    root: /content/uav-obb-urban-vehicle-detection-dataset/UAV-OBB An Aerial Urban Vehicle Dataset with Orien/UAV-OBB/UAV-OBB
  sen12ms:
    root: /content/sen12ms_qa
```

Paths containing spaces are valid YAML strings; quote them when editing by hand if needed.

## D. Validate the current files

```python
!python scripts/validate_datasets.py \
    --config configs/datasets.local.yaml \
    --report results/dataset_validation.json
```

Interpretation:

- `OK`: layout is usable by the adapter;
- `WARN`: partial dataset, missing extraction, or missing labels;
- `MISS`: root or mandatory structure absent.

Expected from the screenshots before additional downloads:

- FloodNet: likely `OK`;
- UAV-OBB: likely `OK` after the deepest root is resolved;
- RSVQA-HR: `WARN` until images are extracted and `USGS_*` pairs are organized;
- RSVQA-LR: `WARN` until LR images are present;
- SEN12MS: `WARN` because `optical/` and `sar/` do not provide ground-truth land-cover labels;
- EarthVQA: `MISS`.

## E. Regenerate UAV-OBB-QA correctly

Do not use the old `uav_obb_questions.json` as final experiment evidence. Run:

```python
import yaml
from pathlib import Path
cfg = yaml.safe_load(Path("configs/datasets.local.yaml").read_text())
uav_root = cfg["datasets"]["uav_obb"]["root"]
print(uav_root)
```

```python
!python scripts/build_uav_obb_qa.py \
    --dataset-root "{uav_root}" \
    --output data/derived/manifests/uav_obb_qa.jsonl
```

In a normal shell or Colab cell where the Python variable is not exported, copy the printed path directly:

```python
!python scripts/build_uav_obb_qa.py \
  --dataset-root "/content/uav-obb-urban-vehicle-detection-dataset/UAV-OBB An Aerial Urban Vehicle Dataset with Orien/UAV-OBB/UAV-OBB" \
  --output data/derived/manifests/uav_obb_qa.jsonl
```

## F. Build normalized manifests for every ready dataset

```python
!python scripts/build_all_manifests.py \
    --config configs/datasets.local.yaml \
    --output-dir data/derived/manifests \
    --include-rsvqa-lr

!ls -lh data/derived/manifests
!head -n 2 data/derived/manifests/uav_obb_qa.jsonl
```

A normalized record contains a unique sample ID, dataset, split, image path(s), question, ground-truth answer, question type, sensor label, and source metadata.

## G. Verify repository code

```python
!pytest -q
```

The packaged release was validated with 29 automated tests. Passing local tests confirms parsers, layout checks, risk-control utilities, attacks, and synthetic visualization code. It does **not** prove that every external dataset file was downloaded correctly; `validate_datasets.py` performs that machine-specific audit.

## H. Generate all 55 figure layouts

```python
!python scripts/generate_v4_extended_suite.py
!python scripts/build_full_figure_gallery.py
```

Outputs:

```text
figures/v4_extended/fig44_... through fig55_...
figures/AdvQFuse_TPAMI_v4_55_Figure_Contact_Sheet.png
figures/AdvQFuse_TPAMI_v4_55_Figure_Gallery.pdf
```

Every demonstration figure is watermarked. Keep synthetic outputs outside the final manuscript evidence folder.

## I. Run the actual research pipeline

The repository separates **dataset preparation**, **model inference**, and **evaluation**. Complete the stages in this order:

```text
1. Dataset validation
2. Manifest generation
3. Clean inference for every model × precision point
4. Corruption and adversarial-example generation
5. Paired precision-path feature extraction
6. Reliability-controller training on training split only
7. Threshold calibration on a disjoint calibration split
8. Locked test evaluation
9. Bootstrap confidence intervals and group-risk audit
10. Real quantitative and qualitative figure generation
```

The current package provides the data adapters, features, controller, risk control, attacks, schemas, and visualization layouts. Model-specific loaders for the final four VLM families must be implemented or connected to the exact checkpoints selected for the experiment; that choice cannot be safely hard-coded before the pilot confirms memory and API compatibility.
